# ResQAlert + DecisionTwin — Prototype Approach, Methods & Models

*(Reference note for the team / evaluators — this is NOT part of the application.)*

## 1. Problem statement → prototype link

The problem statement in the submitted design deck: emergency response today is slow because
dispatch is manual. A call is triaged by voice, severity is judged by an operator, and the
**nearest unit on the map** is sent — with no model of traffic, unit availability, or required
capability. The result is avoidable minutes lost on life-critical calls.

The deck's proposed answer has two halves:

- **ResQAlert** = Detection + Alert + Dispatch + Tracking
- **DecisionTwin** = Digital model + Simulation + Recommendation

The prototype implements the *core module* of exactly that pipeline, end to end:

```
Sense → Alert → Model → Simulate → Decide → Dispatch → Track → Re-simulate → Resolve
```

| Deck component | Implemented in prototype |
|---|---|
| Emergency Detection (report inputs: type, severity, location/GPS, description, people) | Report form on the home page, with live GPS coordinates per zone |
| ResQAlert Core (validate, classify, determine severity, generate incident ID, store) | `classify()` + incident store (`RQ-YYYY-NNN` IDs, log, state machine) |
| DecisionTwin (Incident / Responder / Traffic / Hospital twins) | Fleet & city twin page + the twin datasets driving every run |
| Simulation Engine ("what if the nearest ambulance is delayed?") | `simulate()` — per-unit ETA table + 4 competing response scenarios |
| Decision Engine → Recommended Response Strategy | Weighted scoring, top-ranked strategy marked "Recommended" |
| Dispatch (authorised dispatcher) | "Authorise dispatch" → assigns units, opens the dispatch console |
| Live Response (En route → Arrived → Responding → Resolved) | Live status rail, auto-advancing timeline, decision & status log |
| Live status feeds back → DecisionTwin re-simulates | Re-simulation entry logged on the "en route" status update |
| Traditional vs DecisionTwin-assisted comparison table | ETA / distance / time-saved comparison on both pages |

## 2. What actually runs (real output, not mock-ups)

Every number on screen is computed at click time — nothing is hard-coded:

- Severity score and priority are derived from the report text and inputs.
- Distance, drive time, traffic delay and ETA are computed per unit.
- Four dispatch scenarios are generated, scored and ranked.
- The traditional-dispatch baseline is computed and compared.

Verified sample run (critical medical call, Central Station District, heavy traffic):
severity **CRITICAL score 84 / P1**, 4 scenarios evaluated in ~1 ms, dispatch
`Police P-11 + Ambulance A-01`, DecisionTwin ETA **1.4 min** vs traditional
**~3.8 min** → **2.4 min saved**, then a full live lifecycle through to *Resolved*.

## 3. Models and methods used, start to end

**Stage 1 — Sense / Alert (input model).** Structured report: emergency type, zone with GPS
coordinates, reporter-stated severity, number of people affected, free-text description.

**Stage 2 — Classification model (rule-based / weighted keyword scoring).**
`score = severity base + life-threat keyword weight + escalation keyword weight + scale weight + incident-type risk weight`, clipped to 5–100.
- Base: critical 78 / high 58 / moderate 36 / low 18.
- Life-threat lexicon (`unconscious`, `not breathing`, `cardiac`, `trapped`, `gunshot`, …): +18, +4 per extra hit.
- Escalation lexicon (`fire`, `smoke`, `crash`, `chest pain`, …): +8, +3 per extra hit.
- ≥5 people +12; 2–4 people +5; fire/rescue type +6.
- Bands: ≥80 critical (P1, 8 min SLA), ≥60 high (P2, 12 min), ≥38 moderate (P3, 18 min), else low (P4, 30 min).
- Capability mapping: medical→ambulance; fire→fire+ambulance; crime→police; accident→ambulance+police; rescue→rescue+ambulance; critical calls add police.
- *Why rules, not ML:* it is transparent, auditable (each contributing signal is shown to the dispatcher), and needs no labelled emergency corpus — which is unavailable for this prototype. The same interface can later be swapped for a trained text classifier.

**Stage 3 — Geospatial + ETA prediction model.**
- Haversine great-circle distance between unit and incident (R = 6371 km).
- Road-network correction factor ×1.35 applied to straight-line distance.
- `drive = distance / unit average speed`; unit speeds 36–52 km/h by vehicle class.
- Traffic multiplier: clear 1.0, moderate 1.25, heavy 1.55, gridlock 1.9 — surfaced separately as "traffic delay".
- Plus per-unit mobilisation time (0.8–3.0 min) from alert to wheels rolling.
- `ETA = drive + traffic delay + mobilisation`.

**Stage 4 — Resource matching + scenario simulation.** Four scenarios are generated per incident:
single fastest suitable unit; full capability team dispatched in parallel (ETA = last unit on scene);
staged response (nearest unit stabilises, specialist follows); reserve-aware (second-best unit, keeps
closest unit free for the next call).

**Stage 5 — Decision engine (multi-criteria weighted utility).**
`score = w·speed + (1−w)·capability coverage + SLA bonus − extra-unit penalty`, where the speed
weight `w` rises with severity (0.62 critical, 0.52 high, 0.40 otherwise), speed is normalised as
`1 − ETA/25 min`, an SLA bonus of 0.12 applies when ETA meets the severity target, and extra units
carry a small penalty (much smaller for critical calls, where capability outweighs resource cost).
Highest score becomes the recommendation; the dispatcher can still override it — human authority is
preserved by design.

**Stage 6 — Traditional-dispatch baseline (for the comparison table).** Models today's manual
process: nearest unit by straight-line distance, plus 2.4 min manual phone triage, plus 6.5 min
re-dispatch if that unit is already on a call, plus the delay of sending the wrong capability first.
Time saved = baseline ETA − chosen strategy ETA.

**Stage 7 — Dispatch, tracking and re-simulation.** Incident state machine
`reported → dispatched → en_route → arrived → responding → resolved`, with a timestamped decision
and status log, an auto-advancing live timeline (compressed into seconds for demo purposes), a
manual "force next status" control, and a logged DecisionTwin re-simulation on the first live
status feedback.

## 4. Technology

React 19 + TypeScript on TanStack Start (SSR-capable), Tailwind CSS v4 design tokens.
The decision core is a pure, dependency-free TypeScript module (`src/lib/decision-twin.ts`),
so it is unit-testable and portable to a server/API without change. Incident state lives in an
in-memory reactive store (`src/lib/incident-store.ts`) — no database is required for the prototype.
No external AI/LLM service is used; all intelligence is deterministic and explainable.

## 5. Honest scope / limitations

- Fleet, hospital and traffic data are **simulated demo data** (as stated in the design deck),
  since live municipal responder and traffic feeds are not available.
- Distance is haversine + road factor, not a real routing engine (a Maps/OSRM routing API would drop in
  at the `etaFor()` boundary).
- Classification is lexicon-based, not a trained model.
- Incidents are not persisted across page reloads.
- The live timeline is time-compressed so the full lifecycle is observable in a demo.
