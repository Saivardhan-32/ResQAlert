# Running ResQAlert locally

ResQAlert is a TanStack Start (React + Vite) app. You need **Node.js 20+** installed.

## 1. Install dependencies

```bash
npm install
```

(If you use Bun: `bun install` — a `bun.lock` is included.)

## 2. Run the app

```bash
npm run dev
```

Open http://localhost:5173 (the terminal prints the exact URL).

## 3. AI photo analysis (vision layer)

The photo-analysis features (accident photo → severity, traffic camera → congestion /
police / clearance time) call an AI model. In Lovable this works out of the box.
Running outside Lovable, set your AI gateway key before `npm run dev`:

```bash
export LOVABLE_API_KEY="your-key"
```

Without a key, the rest of the app (report → classification → DecisionTwin simulation
→ dispatch → live tracking → hospital ETA) still works fully — only the two photo
upload panels will report that AI is not configured.

Note: browsers block camera/GPS on plain http from other devices; use `localhost`
or https for the live-location button.

## 4. What to try

**Report page (`/`)** — the full pipeline:
1. Upload a photo of an accident/fire scene → the AI reads it and auto-fills the
   emergency type, severity score, people affected and a summary.
2. Upload a traffic-camera frame → the AI estimates congestion, spots traffic
   police, judges their activity (idle / directing / actively clearing) and
   predicts how many minutes until the road is passable.
3. "Share live location" snaps your GPS fix to the nearest modelled zone.
4. Review/adjust the report and submit → the DecisionTwin engine computes every
   unit's ETA, generates dispatch strategies and recommends one.
5. See the "Ambulance → hospital" ETA: scene arrival + on-scene care + transport,
   including time saved by the officer clearing the lane.
6. "Authorise dispatch" → jump to the console.

**Dispatch console (`/dispatch`)** — live tracking: each incident progresses
through reported → dispatched → en route → arrived → responding → resolved, with a
full decision log and a traditional-baseline vs DecisionTwin time-saved comparison.

**Fleet & city twin (`/fleet`)** — the responders, hospitals and traffic zones the
simulation runs on.

## 5. Production build

```bash
npm run build
npm run preview
```

## Notes

- The responder fleet, hospitals and zones are simulated demo data (live municipal
  responder feeds are not publicly available). The methodology write-up is in
  `docs/ResQAlert-Prototype-Approach-and-Models.md` — kept out of the app on purpose.
